import React from 'react';
import BookConatiner from '../../containers/book_conatiner'

 const BookView = (props) => {
   return (
     <BookConatiner {...props}/>
   );
 }

 export default BookView;