import React from 'react';

 const NotFound404 = () => {
   return (
     <div style={{
       textAlign:'center',
       marginTop:'10%'
     }}>
        <h1>404</h1>
        <p>Oop! Page Not Found</p>
     </div>
   );
 }

 export default NotFound404;